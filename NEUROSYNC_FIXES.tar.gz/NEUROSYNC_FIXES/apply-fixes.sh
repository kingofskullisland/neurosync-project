#!/bin/bash
###############################################################################
# NeuroSync — Apply Audit Fixes
# Run from the repository root: bash FIXES/apply-fixes.sh
###############################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log()         { echo -e "${GREEN}[FIX]${NC} $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_critical(){ echo -e "${RED}[CRITICAL]${NC} $1"; }

echo ""
echo "═══════════════════════════════════════════"
echo "  NeuroSync Audit Fix Application Script   "
echo "═══════════════════════════════════════════"
echo ""

# ── STEP 1: Delete junk/dangerous files ──────────────────────
log_critical "Removing RCE-vulnerable mobile_bridge.py"
rm -f mobile_bridge.py

log "Removing junk/stale files"
rm -f server_PC.py config.js App.js.backup "index copy.tsx.backup"
rm -f v3.txt backend.log mobile_bridge.log
rm -f "my-expo-app.code-workspace" "my-expo-app.code-workspace.txt.code-workspace"
rm -f "udo systemctl stop ollama"

# ── STEP 2: Remove duplicate storage module ──────────────────
log "Removing duplicate utils/storage.ts (replaced by lib/storage.ts)"
rm -rf utils/

# ── STEP 3: Consolidate CI workflows ────────────────────────
log "Cleaning up duplicate CI workflows"
rm -f .github/workflows/android-build.yml
rm -f .github/workflows/build-apk.yml
rm -f .github/workflows/main.yml
rm -f .github/workflows/webpack.yml

# ── STEP 4: Apply fixed files ────────────────────────────────
log "Applying fixed app.json (removed duplicate plugin)"
cp FIXES/app.json app.json

log "Applying fixed package.json (proper name, removed unused deps)"
cp FIXES/package.json package.json

log "Applying fixed .gitignore"
cp FIXES/.gitignore .gitignore

log "Applying fixed API client (removed hardcoded IPs, added history)"
cp FIXES/lib/api.ts lib/api.ts

log "Applying fixed NeuroBeam (honest security documentation)"
cp FIXES/lib/neurobeam.ts lib/neurobeam.ts

log "Applying fixed setup screen (uses lib/storage.ts)"
cp FIXES/app/setup.tsx app/setup.tsx

log "Applying fixed backend main.py (uses request.model, sends history)"
cp FIXES/backend/app/main.py backend/app/main.py

log "Applying fixed backend schemas (history support)"
cp FIXES/backend/app/schemas/responses.py backend/app/schemas/responses.py

log "Applying fixed backend router (imports, no dead code)"
cp FIXES/backend/app/core/router.py backend/app/core/router.py

log "Adding missing __init__.py"
cp FIXES/backend/app/core/__init__.py backend/app/core/__init__.py

log "Adding .env.example"
cp FIXES/backend/.env.example backend/.env.example

log "Applying canonical CI workflow"
cp FIXES/.github/workflows/build-android.yml .github/workflows/build-android.yml

# ── STEP 5: Remove unused Tailwind/NativeWind files ──────────
log "Removing unused NativeWind config files"
rm -f tailwind.config.js global.css nativewind-env.d.ts

echo ""
echo "═══════════════════════════════════════════"
echo "  ✓ All fixes applied successfully         "
echo "═══════════════════════════════════════════"
echo ""
echo "Next steps:"
echo "  1. Run 'npm install' to update dependencies"
echo "  2. Review changes with 'git diff'"
echo "  3. Commit: git add -A && git commit -m 'apply audit fixes'"
echo "  4. Push: git push"
echo ""
