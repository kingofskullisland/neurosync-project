/**
 * NeuroBeam Client Module
 * P2P tunnel for NeuroSync mobile app → Desktop bridge connection
 *
 * ⚠️ SECURITY WARNING: The current "encryption" is a simple XOR cipher
 * and provides NO real security. It is a development placeholder only.
 * Only use NeuroBeam on trusted local networks (e.g., Tailscale VPN).
 *
 * TODO: Replace with tweetnacl-js or @noble/ciphers for production use.
 */
import { Buffer } from 'buffer';
import * as Crypto from 'expo-crypto';

if (typeof global.Buffer === 'undefined') {
    global.Buffer = Buffer;
}

// ─── Types ──────────────────────────────────────────────────

export enum BeamState {
    IDLE = 'idle',
    SCANNING = 'scanning',
    HANDSHAKING = 'handshaking',
    LOCKED = 'locked',
    INTERRUPTED = 'interrupted',
    ERROR = 'error',
}

export interface BeamConfig {
    host: string;
    port: number;
    key: string;
    sid: string;
    v: number;
}

export interface BeamStats {
    state: BeamState;
    latency: number;
    connectedSince: number | null;
    lastError: string | null;
    messagesSent: number;
    messagesReceived: number;
}

type BeamListener = (stats: BeamStats) => void;

// ─── Obfuscation (NOT Encryption) ───────────────────────────

/**
 * XOR-based obfuscation — NOT cryptographically secure.
 * Provides basic obfuscation only. Do NOT rely on this for security.
 * Use only on trusted networks (Tailscale, local LAN).
 */
class BeamObfuscator {
    private key: Uint8Array;

    constructor(keyBase64: string) {
        this.key = Buffer.from(keyBase64, 'base64');
    }

    async obfuscate(plaintext: string): Promise<{ c: string; n: string }> {
        const encoder = new TextEncoder();
        const data = encoder.encode(plaintext);
        const nonce = await Crypto.getRandomBytesAsync(16);

        const output = new Uint8Array(data.length);
        for (let i = 0; i < data.length; i++) {
            output[i] = data[i] ^ this.key[i % this.key.length] ^ nonce[i % nonce.length];
        }

        return {
            c: Buffer.from(output).toString('base64'),
            n: Buffer.from(nonce).toString('base64'),
        };
    }

    async deobfuscate(envelope: { c: string; n: string }): Promise<string> {
        const ciphertext = Buffer.from(envelope.c, 'base64');
        const nonce = Buffer.from(envelope.n, 'base64');

        const output = new Uint8Array(ciphertext.length);
        for (let i = 0; i < ciphertext.length; i++) {
            output[i] = ciphertext[i] ^ this.key[i % this.key.length] ^ nonce[i % nonce.length];
        }

        const decoder = new TextDecoder();
        return decoder.decode(output);
    }
}

// ─── NeuroBeam Client ───────────────────────────────────────

export class NeuroBeam {
    private config: BeamConfig | null = null;
    private obfuscator: BeamObfuscator | null = null;
    private ws: WebSocket | null = null;
    private state: BeamState = BeamState.IDLE;
    private listeners: BeamListener[] = [];
    private stats: BeamStats = {
        state: BeamState.IDLE,
        latency: 0,
        connectedSince: null,
        lastError: null,
        messagesSent: 0,
        messagesReceived: 0,
    };
    private reconnectDelay = 1000;
    private maxReconnectDelay = 30000;
    private reconnectTimer: NodeJS.Timeout | null = null;
    private pingInterval: NodeJS.Timeout | null = null;
    private pendingRequests = new Map<string, {
        resolve: (data: any) => void;
        reject: (error: Error) => void;
        timeout: NodeJS.Timeout;
    }>();

    async connect(config: BeamConfig): Promise<void> {
        this.config = config;
        this.obfuscator = new BeamObfuscator(config.key);
        this.setState(BeamState.HANDSHAKING);

        return new Promise((resolve, reject) => {
            const wsUrl = `ws://${config.host}:${config.port}`;
            this.ws = new WebSocket(wsUrl);

            const connectionTimeout = setTimeout(() => {
                this.ws?.close();
                reject(new Error('Connection timeout'));
            }, 10000);

            this.ws.onopen = async () => {
                try {
                    const handshake = { type: 'handshake', sid: config.sid };
                    this.ws!.send(JSON.stringify(handshake));
                } catch (error) {
                    clearTimeout(connectionTimeout);
                    reject(error);
                }
            };

            this.ws.onmessage = async (event) => {
                try {
                    const data = JSON.parse(event.data);

                    if (this.state === BeamState.HANDSHAKING) {
                        clearTimeout(connectionTimeout);
                        const decrypted = await this.obfuscator!.deobfuscate(data);
                        const response = JSON.parse(decrypted);

                        if (response.type === 'handshake_ok') {
                            this.setState(BeamState.LOCKED);
                            this.stats.connectedSince = Date.now();
                            this.reconnectDelay = 1000;
                            this.startPing();
                            resolve();
                        } else {
                            throw new Error('Handshake failed');
                        }
                    } else {
                        await this.handleMessage(data);
                    }
                } catch (error: any) {
                    clearTimeout(connectionTimeout);
                    this.handleError(error);
                    reject(error);
                }
            };

            this.ws.onerror = () => {
                clearTimeout(connectionTimeout);
                this.handleError(new Error('WebSocket error'));
                reject(new Error('WebSocket error'));
            };

            this.ws.onclose = () => {
                clearTimeout(connectionTimeout);
                this.handleDisconnect();
            };
        });
    }

    disconnect(): void {
        this.stopPing();
        this.clearPendingRequests('Disconnected');
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
        this.setState(BeamState.IDLE);
        this.stats.connectedSince = null;
    }

    private clearPendingRequests(reason: string): void {
        for (const [id, pending] of this.pendingRequests) {
            clearTimeout(pending.timeout);
            pending.reject(new Error(reason));
        }
        this.pendingRequests.clear();
    }

    private async handleMessage(envelope: { c: string; n: string }): Promise<void> {
        try {
            const decrypted = await this.obfuscator!.deobfuscate(envelope);
            const message = JSON.parse(decrypted);
            this.stats.messagesReceived++;

            if (message.type === 'pong') {
                const now = Date.now();
                const sent = message.timestamp ? new Date(message.timestamp).getTime() : now;
                this.stats.latency = now - sent;
            } else if (message.type === 'response') {
                const requestId = message.id || 'default';
                const pending = this.pendingRequests.get(requestId);
                if (pending) {
                    clearTimeout(pending.timeout);
                    pending.resolve(message.data);
                    this.pendingRequests.delete(requestId);
                }
            } else if (message.type === 'error') {
                this.handleError(new Error(message.error));
            }

            this.notifyListeners();
        } catch (error: any) {
            this.handleError(error);
        }
    }

    private handleDisconnect(): void {
        if (this.state === BeamState.LOCKED) {
            this.setState(BeamState.INTERRUPTED);
            this.scheduleReconnect();
        }
    }

    private handleError(error: Error): void {
        this.stats.lastError = error.message;
        this.setState(BeamState.ERROR);
        this.notifyListeners();
    }

    private scheduleReconnect(): void {
        if (this.reconnectTimer) return;

        this.reconnectTimer = setTimeout(async () => {
            this.reconnectTimer = null;
            if (this.config) {
                try {
                    await this.connect(this.config);
                } catch {
                    this.reconnectDelay = Math.min(this.reconnectDelay * 2, this.maxReconnectDelay);
                    this.scheduleReconnect();
                }
            }
        }, this.reconnectDelay);
    }

    private startPing(): void {
        this.pingInterval = setInterval(async () => {
            if (this.state === BeamState.LOCKED) {
                try {
                    await this.send({ type: 'ping', timestamp: new Date().toISOString() });
                } catch {
                    // Ping failed — will trigger reconnect via onclose
                }
            }
        }, 10000);
    }

    private stopPing(): void {
        if (this.pingInterval) {
            clearInterval(this.pingInterval);
            this.pingInterval = null;
        }
    }

    private async send(payload: any): Promise<void> {
        if (!this.ws || this.state !== BeamState.LOCKED) {
            throw new Error('Beam not locked');
        }

        const encrypted = await this.obfuscator!.obfuscate(JSON.stringify(payload));
        this.ws.send(JSON.stringify(encrypted));
        this.stats.messagesSent++;
        this.notifyListeners();
    }

    async request(path: string, options: {
        method?: 'GET' | 'POST';
        body?: any;
    } = {}): Promise<any> {
        const requestId = Math.random().toString(36).substring(7);

        const payload = {
            type: 'request',
            id: requestId,
            path,
            method: options.method || 'GET',
            body: options.body,
        };

        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                if (this.pendingRequests.has(requestId)) {
                    this.pendingRequests.delete(requestId);
                    reject(new Error('Request timeout'));
                }
            }, 120000);

            this.pendingRequests.set(requestId, { resolve, reject, timeout });

            this.send(payload).catch((error) => {
                clearTimeout(timeout);
                this.pendingRequests.delete(requestId);
                reject(error);
            });
        });
    }

    private setState(newState: BeamState): void {
        this.state = newState;
        this.stats.state = newState;
        this.notifyListeners();
    }

    getStats(): BeamStats {
        return { ...this.stats };
    }

    onUpdate(listener: BeamListener): () => void {
        this.listeners.push(listener);
        return () => {
            this.listeners = this.listeners.filter((l) => l !== listener);
        };
    }

    private notifyListeners(): void {
        this.listeners.forEach((listener) => listener(this.getStats()));
    }
}

export const neurobeam = new NeuroBeam();
