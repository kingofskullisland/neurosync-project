/**
 * NeuroSync API Client
 * Connects to Python bridge on configurable port, proxies to Ollama
 */

const BRIDGE_PORT = 8082;
const DEFAULT_TIMEOUT = 5000;
const CHAT_TIMEOUT = 120000;

export interface HealthResponse {
    status: string;
    system: string;
    ollama: 'connected' | 'unreachable';
}

export interface ChatResponse {
    model: string;
    created_at?: string;
    response: string;
    done: boolean;
    persona?: string;
    routing?: string;
    complexity_score?: number;
}

export interface ChatMessage {
    role: 'user' | 'assistant' | 'system';
    content: string;
}

export interface ModelInfo {
    name: string;
    model: string;
    size: number;
    details?: {
        parameter_size: string;
        quantization_level: string;
    };
}

export interface ModelsResponse {
    models: ModelInfo[];
}

export class NetworkError extends Error {
    constructor(message: string, public code?: number) {
        super(message);
        this.name = 'NetworkError';
    }
}

// Request deduplication - prevents double-tap sending duplicate messages
let activeRequest: AbortController | null = null;

async function fetchWithTimeout(
    url: string,
    options: RequestInit = {},
    timeout: number = DEFAULT_TIMEOUT
): Promise<Response> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal,
        });
        clearTimeout(timeoutId);
        return response;
    } catch (error: any) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            throw new NetworkError('Connection timed out');
        }
        throw new NetworkError('Network unreachable');
    }
}

function buildUrl(ip: string, port: number = BRIDGE_PORT): string {
    const cleanIp = ip.replace(/^https?:\/\//, '').replace(/:\d+$/, '');
    return `http://${cleanIp}:${port}`;
}

export async function checkHealth(ip: string): Promise<HealthResponse> {
    const url = `${buildUrl(ip)}/health`;
    try {
        const response = await fetchWithTimeout(url, { method: 'GET' });
        if (!response.ok) {
            throw new NetworkError(`Bridge error: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        if (error instanceof NetworkError) throw error;
        throw new NetworkError('Failed to check health');
    }
}

export async function getModels(ip: string): Promise<ModelsResponse> {
    const url = `${buildUrl(ip)}/models`;
    try {
        const response = await fetchWithTimeout(url, { method: 'GET' });
        if (!response.ok) {
            throw new NetworkError(`Models error: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        if (error instanceof NetworkError) throw error;
        throw new NetworkError('Failed to get models');
    }
}

/**
 * Send chat with conversation history context
 * Fix #15: Sends message history for multi-turn conversations
 * Fix #28: Cancels any in-flight request to prevent duplicates
 */
export async function sendChat(
    ip: string,
    prompt: string,
    model: string = 'llama3.2:latest',
    history: ChatMessage[] = []
): Promise<ChatResponse> {
    // Cancel any existing request (dedup)
    if (activeRequest) {
        activeRequest.abort();
    }
    activeRequest = new AbortController();

    const url = `${buildUrl(ip)}/chat`;

    try {
        const response = await fetchWithTimeout(
            url,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    prompt,
                    model,
                    history: history.slice(-10), // Last 10 messages for context
                }),
                signal: activeRequest.signal,
            },
            CHAT_TIMEOUT
        );

        if (!response.ok) {
            if (response.status === 503) {
                throw new NetworkError('Ollama unavailable. Start the AI server on PC.', 503);
            }
            if (response.status === 504) {
                throw new NetworkError('AI processing timed out', 504);
            }
            const data = await response.json().catch(() => ({}));
            throw new NetworkError(data.error || `Server error: ${response.status}`);
        }

        const data = await response.json();

        if (data.error) {
            throw new NetworkError(data.error);
        }

        if (!data.response) {
            throw new NetworkError('Empty response from AI');
        }
        return data;
    } catch (error) {
        if (error instanceof NetworkError) throw error;
        if ((error as any).name === 'AbortError') {
            throw new NetworkError('Request cancelled');
        }
        throw new NetworkError('Failed to send chat');
    } finally {
        activeRequest = null;
    }
}
