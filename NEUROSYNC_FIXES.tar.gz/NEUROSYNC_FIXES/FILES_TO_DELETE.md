# Files to DELETE from the repository

## Critical Deletions (Security/Cleanup)
rm mobile_bridge.py            # CRITICAL: Contains RCE endpoint + replaced by FastAPI backend
rm server_PC.py                # Unused raw socket server
rm config.js                   # Empty/hardcoded IP, unused  
rm App.js.backup               # Stale backup from old architecture
rm "index copy.tsx.backup"     # Stale backup
rm v3.txt                      # 367KB conversation dump — no place in repo
rm backend.log                 # Debug log leaked to repo
rm mobile_bridge.log           # Debug log leaked to repo  
rm "my-expo-app.code-workspace"               # VS Code workspace file
rm "my-expo-app.code-workspace.txt.code-workspace"  # Duplicate
rm "udo systemctl stop ollama"  # Accidental file from terminal typo

## Duplicate/Conflicting Files
rm utils/storage.ts            # Replaced by lib/storage.ts (Flaw #5)
rm .github/workflows/android-build.yml  # Duplicate (Flaw #8)
rm .github/workflows/build-apk.yml      # Duplicate (Flaw #8)
rm .github/workflows/main.yml           # Empty file (Flaw #8)
rm .github/workflows/webpack.yml        # No webpack config exists (Flaw #8)
