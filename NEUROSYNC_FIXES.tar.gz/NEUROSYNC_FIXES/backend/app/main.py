"""
NeuroSync Router - FastAPI Application
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import json
import logging
import httpx

from .core.config import settings
from .core.router import router as ai_router, RouteTarget
from .core.scorer import scorer
from .core.prompts import get_system_prompt, Persona
from .schemas.responses import ChatRequest, ChatResponse, HealthResponse, ModelListResponse

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown events"""
    logger.info("NeuroSync Router starting...")
    backends = await ai_router.check_backends()
    logger.info(f"Backend status: {backends}")
    yield
    logger.info("NeuroSync Router shutting down...")


app = FastAPI(
    title="NeuroSync Router",
    description="Tier 2 — Intelligent AI Request Router",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# REST ENDPOINTS
# =============================================================================

@app.get("/health")
async def health():
    """Health check with backend status"""
    ollama_status = "offline"

    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            resp = await client.get(f"{settings.OLLAMA_URL}/api/tags")
            if resp.status_code == 200:
                ollama_status = "online"
    except Exception:
        pass

    return {
        "status": "online",
        "system": "NEUROSYNC_ROUTER",
        "ollama": "connected" if ollama_status == "online" else "unreachable",
        "bridge": "online"
    }


@app.get("/models")
async def list_models():
    """List available Ollama models"""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{settings.OLLAMA_URL}/api/tags")

            if response.status_code == 200:
                data = response.json()
                return {"models": data.get("models", [])}
            else:
                logger.error(f"Ollama /api/tags returned {response.status_code}")
                return {"error": f"Ollama returned {response.status_code}", "models": []}

    except Exception as e:
        logger.error(f"Failed to fetch models: {e}")
        return {"error": str(e), "models": []}


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Chat endpoint — routes query and returns AI response.
    Fix #4: Uses request.model instead of hardcoded model.
    Fix #15: Passes conversation history for multi-turn context.
    """
    # Use client-specified model or fall back to configured default
    model = request.model or settings.OLLAMA_MODEL

    # Route the query
    decision = await ai_router.route(
        query=request.prompt,
        has_image=bool(request.image),
        has_screen=bool(request.screen),
        image_data=request.image
    )

    decision_score = decision.complexity

    # Build system prompt
    system_prompt_obj = get_system_prompt(Persona.HADRON)
    system_prompt = system_prompt_obj.prompt.format(system_state="Status: Nominal")

    # Build message array with history context (Fix #15)
    messages = [{"role": "system", "content": system_prompt}]

    # Add conversation history if provided
    if request.history:
        for msg in request.history[-10:]:  # Last 10 messages
            messages.append({"role": msg.role, "content": msg.content})

    # Add current user message
    messages.append({"role": "user", "content": request.prompt})

    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": 0.4,
            "num_predict": 512
        }
    }

    try:
        base_url = settings.OLLAMA_URL.rstrip('/')

        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{base_url}/api/chat",
                json=payload
            )

        if response.status_code == 200:
            data = response.json()
            ai_text = data.get('message', {}).get('content', "Err: Empty buffer.")

            return ChatResponse(
                response=ai_text,
                persona="HADRON",
                routing="LOCAL",
                model_used=model,
                complexity_score=decision_score
            )
        else:
            return ChatResponse(
                response=f"[COMM-FAILURE] Ollama returned {response.status_code}",
                persona="ERROR",
                routing="NONE",
                model_used="none",
                complexity_score=decision_score
            )

    except Exception as e:
        logger.error(f"Chat Error: {e}")
        return ChatResponse(
            response=f"[COMM-FAILURE] {str(e)}",
            persona="ERROR",
            routing="NONE",
            model_used="none",
            complexity_score=0.0
        )


@app.get("/score")
async def score_query(query: str):
    """Debug endpoint: score a query without executing"""
    result = scorer.score(query)
    return {
        "score": result.score,
        "factors": result.factors,
        "recommendation": result.recommendation,
    }


# =============================================================================
# WEBSOCKET (STREAMING)
# =============================================================================

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for streaming AI responses."""
    await websocket.accept()
    logger.info("WebSocket client connected")

    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)

            msg_type = message.get("type", "text")
            payload = message.get("payload", "")
            stream_id = message.get("streamId", "default")

            has_image = msg_type == "image"
            has_screen = msg_type == "screen"
            image_data = payload if (has_image or has_screen) else None
            query = payload if msg_type == "text" else "Analyze this image"

            decision = await ai_router.route(
                query=query,
                has_image=has_image,
                has_screen=has_screen,
                image_data=image_data,
            )

            logger.info(f"Routing to {decision.target.value}: {decision.reason}")

            async for chunk in ai_router.execute(query, decision, image_data):
                await websocket.send_text(json.dumps({
                    "type": "complete" if chunk.done else "token",
                    "content": chunk.content,
                    "route": chunk.route.value,
                    "streamId": stream_id,
                }))

    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            await websocket.send_text(json.dumps({
                "type": "error",
                "content": str(e),
                "route": "LOCAL",
                "streamId": "error",
            }))
        except Exception:
            pass


# =============================================================================
# ENTRYPOINT
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
    )
